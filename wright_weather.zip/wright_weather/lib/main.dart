import 'dart:async';
import 'dart:convert';

import 'package:animations/animations.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geocoder/geocoder.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:location/location.dart' as location_plugin;
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'forecast.dart';
import 'locationData.dart';
import 'search.dart';
import 'settings.dart';
import 'splashscreen.dart';

///global variables for access in settings file
SharedPreferences prefs;
bool celsius;
bool dark;

main() async {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  /// This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark));

    return MaterialApp(
      title: 'Wright Weather',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        primaryColorLight: Colors.blue,
        primaryColorDark: Colors.blue[900],
        primaryColorBrightness: Brightness.dark,
        accentColor: Colors.deepOrange[300],
        dividerColor: Colors.black,
        colorScheme: ColorScheme.fromSwatch(
          primarySwatch: Colors.blue,
        ),
        // This makes the visual density adapt to the platform that you run
        // the app on. For desktop platforms, the controls will be smaller and
        // closer together (more dense) than on mobile platforms.
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: SplashPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  MainPage({Key key}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  @override
  MainPageState createState() => MainPageState();
}

class MainPageState extends State<MainPage> with TickerProviderStateMixin {
  static List cityList;
  static bool prefsSet = false;

  /// gets the last list of locations from shared prefs plugin
  static List<Location> locations = prefs?.get('locations') ?? [];

  ///gets last known location from lat and lon
  static location_plugin.LocationData currentLocation;
  static location_plugin.Location locator = location_plugin.Location();

  ///refreshes location and forecast every 6 hours
  static Timer timer;

  ///key for animated list to insert items
  static GlobalKey<AnimatedListState> _listKey = GlobalKey();

  ///for snackbars
  static GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  ///keeps track of list view or card view
  static bool listView = false;

  ///list view animated icon controller
  static AnimationController _iconController;

  ///used to animate to position
  static ScrollController _scrollController = ScrollController();

  ///FadeScaleTransition controller (search and FAB)
  static AnimationController fadeScaleController;

  ///adds the passed location in locations
  void addLocation(Location location) async {
    List<Address> addresses =
        await Geocoder.local.findAddressesFromQuery('${location.name}');

    DateFormat format = DateFormat('h:mm a');

    location.lon = addresses.first.coordinates.longitude;
    location.lat = addresses.first.coordinates.latitude;
    location.time = format.format(DateTime.now());
    if (!locations.contains(location)) {
      locations.add(location);
      getForecast(location)
          .then((value) => insertLocation(locations.indexOf(location)));
    } else {
      _scaffoldKey.currentState.showSnackBar(SnackBar(
        duration: Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        content: Text(
          '${location.name} already added',
          textAlign: TextAlign.center,
          style: GoogleFonts.lato(),
        ),
      ));
    }
  }

  void removeLocation(Location location, onComplete) {
    ///removes with animated list animation
//    int index = locations.indexOf(location);
//    locations.remove(location);
//    prefs.setString('locations', Location.encodeList(locations));
//    _listKey.currentState.removeItem(index, (context, animation) {
//      animation.addStatusListener((AnimationStatus status) {
//        if (status == AnimationStatus.completed ||
//            status == AnimationStatus.dismissed) {
//          onComplete();
//        }
//      });
//
//      return buildDraggable(location, animation);
//    }, duration: Duration(milliseconds: 300));
    ///removes with Dismissable swipe
    int index = locations.indexOf(location);
    locations.remove(location);
    if (prefsSet) prefs.setString('locations', Location.encodeList(locations));
    _listKey.currentState.removeItem(index, (context, animation) => null);

    _scaffoldKey.currentState.showSnackBar(SnackBar(
      duration: Duration(seconds: 3),
      behavior: SnackBarBehavior.floating,
      content: Text(
        '${location.name} removed',
        textAlign: TextAlign.center,
        style: GoogleFonts.lato(),
      ),
    ));
  }

  ///get and add current location to locations list
  Future<void> _getCurrentLocation() async {
    if (await Permission.location.serviceStatus.isEnabled) {
      if (await Permission.locationAlways.isGranted) {
        locator.onLocationChanged.listen((location) {
          currentLocation = location;
        });
      } else if (await Permission.location.request().isGranted) {
        currentLocation = await locator.getLocation();
      }

      List<Address> addresses = await Geocoder.local
          .findAddressesFromCoordinates(Coordinates(
              currentLocation?.latitude, currentLocation?.longitude));

      DateFormat format = DateFormat('h:mm a');

      Location location = Location(
          name: '${addresses.first.locality}, ${addresses.first.adminArea}',
          lon: currentLocation.longitude,
          lat: currentLocation.latitude,
          isCurrentLocation: true,
          time: format.format(DateTime.fromMillisecondsSinceEpoch(
              currentLocation.time.toInt())));

      if (locations.isEmpty) {
        locations.add(location);
        getForecast(location)
            .then((value) => insertLocation(locations.indexOf(location)));
      } else {
        setState(() {
          getForecast(location);
        });
      }
    } else {
      showDialog(
          context: context,
          builder: (context) {
            return SimpleDialog(
              useMaterialBorderRadius: true,
              title: Text(
                'Enable location services',
                style: GoogleFonts.lato(),
              ),
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 100, right: 100),
                  child: RaisedButton(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5)),
                    color: Colors.blue[600],
                    onPressed: () {
                      Navigator.of(context).pop();
                      _getCurrentLocation();
                    },
                    child: Text(
                      'OK',
                      style: GoogleFonts.lato(color: Colors.white),
                    ),
                  ),
                )
              ],
            );
          });
    }
  }

  ///gets all forecasts from NWS and sets them in forecast object of each location
  ///adds to animated list
  static Future<void> getForecast(Location location) async {
    http.Response response = await http
        .get('https://api.weather.gov/points/${location.lat},${location.lon}');

    location.forecast = Forecast.fromJSON(json.decode(response.body));
    await location.forecast.setConditions();

    if (prefsSet) prefs.setString('locations', Location.encodeList(locations));
  }

  static insertLocation(index) => _listKey.currentState
      .insertItem(index, duration: Duration(milliseconds: 500));

  toCelsius(temp) {
    if (temp == '') return temp;
    return ((temp - 32) * 5.0 / 9).round();
  }

  buildCityList() async {
    String data = await rootBundle.loadString('assets/usaCities.json');
    cityList = await json.decode(data);
    showSearch(context: context, delegate: Delegate(cityList)).then((value) {
      if (value != null) addLocation(Location(name: value));
    });
  }

  /// sets variables that need context and begins to get current location
  /// getCurrentLocation() is in initState() so that it is called once at
  /// the beginning of the app
  @override
  void initState() {
    super.initState();

    //set up shared preferences
    SharedPreferences.getInstance().then((value) {
      prefs = value;
      locations = Location.decodeList(prefs.get('locations') ?? "[]") ?? [];
      celsius = prefs.get('celsius') ?? false;
      dark = prefs.get('dark') ?? false;
      listView = prefs.get('listView') ?? false;
      if (listView) _iconController.forward();
      prefsSet = true;
      Future.forEach(locations, (location) {
        getForecast(location);
        insertLocation(locations.indexOf(location));
      }).then((value) => _getCurrentLocation());
    });

    //dark icons in status bar
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark));

    //view list animated icon controller
    _iconController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 300));
    fadeScaleController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 300));

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Future.delayed(Duration(milliseconds: 200), () {
        fadeScaleController.forward();
      });

      //timer to update current location and forecasts
      timer = Timer.periodic(Duration(hours: 6), (timer) {
        setState(() {
          Future.forEach(locations, (location) {
            if (!location.isCurrentLocation) getForecast(location);
          }).then((value) => _getCurrentLocation());
        });
      });
    });
  }

  @override
  void dispose() {
    super.dispose();
    timer?.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      extendBody: true,
      floatingActionButton: FadeScaleTransition(
        animation: fadeScaleController,
        child: FloatingActionButton(
          onPressed: () => buildCityList(),
          child: Icon(Icons.add, color: Colors.white),
          backgroundColor: Theme.of(context).accentColor,
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        shape: CircularNotchedRectangle(),
        color: Colors.black.withOpacity(.5),
        elevation: 0,
        child: Row(
          children: <Widget>[
            IconButton(
                icon: Icon(
                  Icons.settings,
                  color: Colors.white,
                ),
                onPressed: () => Navigator.of(context).push(SharedAxisPageRoute(
                    page: SettingsPage(),
                    transitionType: SharedAxisTransitionType.horizontal))),
            Spacer(),
            IconButton(
              icon: AnimatedIcon(
                icon: AnimatedIcons.list_view,
                progress: _iconController,
                color: Colors.white,
              ),
              onPressed: () {
                listView
                    ? _iconController.reverse()
                    : _iconController.forward();

                setState(() => listView = !listView);
                prefs.setBool('listView', listView);
              },
            )
          ],
        ),
      ),
      body: NestedScrollView(
        physics: BouncingScrollPhysics(),
        headerSliverBuilder: (context, index) {
          return [
            SliverAppBar(
              brightness: Brightness.light,
              snap: true,
              floating: true,
              title: FadeScaleTransition(
                  child: buildSearchBar(), animation: fadeScaleController),
              backgroundColor: Colors.transparent,
              elevation: 0,
            )
          ];
        },
        body: AnimatedList(
            controller: _scrollController,
            shrinkWrap: true,
            key: _listKey,
            initialItemCount: locations.length,
            physics: BouncingScrollPhysics(),
            itemBuilder: (context, index, Animation animation) {
              return buildDraggable(locations[index], animation);
            }),
      ),
    );
  }

  ///builds draggable container for card/list tile
  Widget buildDraggable(Location location, Animation animation) {
    return LongPressDraggable(
      feedback: Container(
        color: Colors.transparent,
        child: Card(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: FittedBox(
              fit: BoxFit.fitWidth,
              child: Text(
                location?.name,
                textAlign: TextAlign.center,
                style: GoogleFonts.questrial(
                    fontWeight: FontWeight.bold,
                    fontSize: 25,
                    color: Colors.blue),
              ),
            ),
          ),
        ),
      ),
      childWhenDragging: Container(),
      child: Container(
          padding: EdgeInsets.all(10),
          child: FadeTransition(
              opacity: animation.drive(Tween(begin: 0, end: 1)),
              child: SlideTransition(
                  position: animation.drive(
                      Tween(begin: Offset(0, .1), end: Offset.zero)
                          .chain(CurveTween(curve: Curves.easeOutCirc))),
                  child: Dismissible(
                      key: Key(location.name),
                      background: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Row(
                          children: [
                            Icon(
                              Icons.delete,
                              size: 30,
                              color: Colors.red,
                            ),
                            Spacer(),
                            Icon(
                              Icons.delete,
                              size: 30,
                              color: Colors.red,
                            ),
                          ],
                        ),
                      ),
                      onDismissed: (direction) {
                        !location.isCurrentLocation
                            ? removeLocation(location, () {})
                            : _scaffoldKey.currentState.showSnackBar(SnackBar(
                                duration: Duration(seconds: 3),
                                behavior: SnackBarBehavior.floating,
                                action: SnackBarAction(
                                  label: 'UNDO',
                                  onPressed: () => _getCurrentLocation(),
                                ),
                                content: Text(
                                  'Current location removed',
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.lato(),
                                ),
                              ));
                      },
                      child: AnimatedCrossFade(
                        duration: Duration(milliseconds: 300),
                        crossFadeState: listView
                            ? CrossFadeState.showSecond
                            : CrossFadeState.showFirst,
                        firstCurve: Curves.decelerate,
                        secondCurve: Curves.decelerate,
                        sizeCurve: Curves.decelerate,
                        firstChild: buildCard(location),
                        secondChild: buildListTile(location),
                      ))))),
    );
  }

  ///builds each card for the card view mode
  Widget buildCard(Location location) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        child: Padding(
            padding: EdgeInsets.all(15),
            child: Column(
              children: [
                Row(children: [
                  location.isCurrentLocation
                      ? Icon(
                          Icons.location_on,
                          color: Colors.grey[600],
                        )
                      : Container(),
                  SizedBox(
                    width: 10,
                  ),
                  Container(
                    width: 200,
                    child: FittedBox(
                      fit: BoxFit.contain,
                      child: Text(
                        location?.name,
                        textAlign: TextAlign.center,
                        style: GoogleFonts.questrial(
                            fontWeight: FontWeight.bold,
                            fontSize: 25,
                            color: Colors.blue),
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
                    width: 50,
                    child: FittedBox(
                      fit: BoxFit.contain,
                      child: Text('${location.time}',
                          style: GoogleFonts.lato(
                              fontStyle: FontStyle.italic,
                              fontSize: 12,
                              color: Colors.grey)),
                    ),
                  ),
                  Spacer(),
                  Text(
                      celsius
                          ? '${toCelsius(location.forecast?.getDaily(0, 'temperature')) ?? ''}°'
                          : '${location.forecast?.getDaily(0, 'temperature') ?? ''}°',
                      style: GoogleFonts.questrial(
                          fontSize: 36,
                          color: Theme.of(context).accentColor,
                          fontWeight: FontWeight.bold))
                ]),
                RichText(
                    text: TextSpan(
                        text:
                            location.forecast?.getDaily(0, 'detailedForecast'),
                        style: GoogleFonts.lato(
                            fontSize: 18,
                            color: Colors.black,
                            fontStyle: FontStyle.italic)))
              ],
            )),
      ),
    );
  }

  ///builds each list tile for the list view mode
  Widget buildListTile(Location location) {
    return Column(
      children: [
        Theme(
          data: ThemeData(dividerColor: Colors.transparent),
          child: ExpansionTile(
              maintainState: true,
              children: [
                Container(
                  height: 70,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    physics: BouncingScrollPhysics(),
                    children: List.generate(13, (index) {
                      if (!(location.forecast?.getDaily(index, 'name') ??
                              'Loading')
                          .contains(RegExp('night', caseSensitive: false))) {
                        return Padding(
                          padding: EdgeInsets.all(15),
                          child: Column(
                            children: [
                              Center(
                                  child: Text(
                                '${location.forecast?.getDaily(index, 'name')}',
                                style: GoogleFonts.lato(
                                    fontWeight: FontWeight.bold),
                              )),
                              Center(
                                child: Text(
                                  celsius
                                      ? '${toCelsius(location.forecast?.getDaily(index, 'temperature')) ?? ''}° / '
                                          '${toCelsius(location.forecast?.getDaily(index + 1, 'temperature')) ?? ''}°'
                                      : '${location.forecast?.getDaily(index, 'temperature') ?? ''}° / '
                                          '${location.forecast?.getDaily(index + 1, 'temperature') ?? ''}°',
                                  style: GoogleFonts.lato(),
                                ),
                              )
                            ],
                          ),
                        );
                      }
                      return Container();
                    }),
                  ),
                ),
                Divider(
                  color: Colors.black,
                  indent: 30,
                  endIndent: 30,
                )
              ],
//          contentPadding: EdgeInsets.fromLTRB(20, 0, 20, 0),
              leading: location.isCurrentLocation
                  ? Icon(
                      Icons.location_on,
                      color: Colors.grey[600],
                    )
                  : null,
              title: RichText(
                text: TextSpan(
                  text: location?.name,
                  style: GoogleFonts.questrial(
                      fontWeight: FontWeight.bold,
                      fontSize: 25,
                      color: Colors.blue),
                ),
              ),
              trailing: Text(
                  '${location.forecast?.getDaily(0, 'temperature')}°',
                  style: GoogleFonts.questrial(
                      fontSize: 36,
                      color: Theme.of(context).accentColor,
                      fontWeight: FontWeight.bold)),
              subtitle: Text(
                  '${location.forecast?.getDaily(0, 'shortForecast')}',
                  style: GoogleFonts.lato(
                      fontSize: 16,
                      color: Colors.black,
                      fontStyle: FontStyle.italic))),
        )
      ],
    );
  }

  ///builds app bar search bar
  Widget buildSearchBar() {
    return GestureDetector(
      onTap: () {
        buildCityList();
      },
      child: Card(
        elevation: 5,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              Icon(
                Icons.search,
                size: 30,
                color: Colors.grey,
              ),
              SizedBox(
                width: 10,
              ),
              Text('Search locations',
                  style: GoogleFonts.lato(
                      color: Colors.grey,
                      fontSize: 20,
                      fontStyle: FontStyle.italic))
            ],
          ),
        ),
      ),
    );
  }
}

/// allows for easier syntax when using SharedAxisTransition
class SharedAxisPageRoute extends PageRouteBuilder {
  SharedAxisPageRoute({Widget page, SharedAxisTransitionType transitionType})
      : super(
          pageBuilder: (
            BuildContext context,
            Animation<double> primaryAnimation,
            Animation<double> secondaryAnimation,
          ) =>
              page,
          transitionsBuilder: (
            BuildContext context,
            Animation<double> primaryAnimation,
            Animation<double> secondaryAnimation,
            Widget child,
          ) {
            return SharedAxisTransition(
              animation: primaryAnimation,
              secondaryAnimation: secondaryAnimation,
              transitionType: transitionType,
              child: child,
            );
          },
        );
}
