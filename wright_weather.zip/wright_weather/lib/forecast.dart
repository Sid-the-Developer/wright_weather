import 'dart:convert';

import 'package:http/http.dart' as http;

class Forecast {
  dynamic days = [];
  dynamic hours;
  String forecastUrl;
  String hourlyForecastUrl;
  bool conditionsSet = false;

  Forecast.fromJSON(Map<String, dynamic> data) {
    try {
      forecastUrl = data['properties']['forecast'];
      hourlyForecastUrl = data['properties']['forecastHourly'];
    } catch (NoSuchMethodError) {
      forecastUrl = data['forecastUrl'];
      hourlyForecastUrl = data['hourlyForecastUrl'];
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'days': days,
      'hours': hours,
      'forecastUrl': forecastUrl,
      'hourlyForecastUrl': hourlyForecastUrl,
      'conditionsSet': conditionsSet
    };
  }

  setConditions() async {
    http.Response response = await http.get(forecastUrl);
    Map data = json.decode(response.body);
    days = data['properties']['periods'];

    http.Response hourlyResponse = await http.get(hourlyForecastUrl);
    Map hourlyData = json.decode(hourlyResponse.body);
    hours = hourlyData['properties']['periods'];

    conditionsSet = true;
  }

  getDaily(int day, String item) {
    if (conditionsSet)
      return days[day][item];
    else {
      return '';
    }
  }

  getHourly(int hour, String item) {
    if (conditionsSet)
      return hours[hour][item];
    else {
      return '';
    }
  }
}
